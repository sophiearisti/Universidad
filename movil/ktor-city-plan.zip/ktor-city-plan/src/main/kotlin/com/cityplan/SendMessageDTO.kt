package com.cityplan

import com.google.firebase.messaging.Message
import com.google.firebase.messaging.Notification
import kotlinx.serialization.Serializable
import java.time.LocalDateTime
@Serializable
data class SendMessageDTO (
    val to: String?,
    val notification: NotificationBody
)
@Serializable
data class NotificationBody(
    val title: String,
    val body: String,
    val id:String,
    val alarmId:Int,
    val idGrupo:String
)

fun SendMessageDTO.toMessage(): Message {
    return Message.builder()
        .setNotification(
            Notification.builder()
                .setTitle(notification.title)
                .setBody(notification.body)
                .build()
        )
        .apply {
            if(to=="1")
            {
                setTopic(notification.idGrupo)
            }
            else
            {
                setToken(to)
            }
        }
        .build()
}