package com.cityplan

import com.google.firebase.messaging.FirebaseMessaging
import com.google.rpc.BadRequest
import io.ktor.http.*
import io.ktor.server.request.*
import io.ktor.server.routing.*

fun Route.sendNotification(){
    route("/send"){
        post {
            val body=call.receiveNullable<SendMessageDTO>() ?: kotlin.run{
                call.respond(HttpStatusCode.BadRequest,typeInfo = null)
                return@post
            }

            FirebaseMessaging.getInstance().send(body.toMessage())
            call.respond(HttpStatusCode.OK,typeInfo = null)
        }
    }

    route("/broadcast"){
        post {
            val body=call.receiveNullable<SendMessageDTO>() ?: kotlin.run{
                call.respond(HttpStatusCode.BadRequest,typeInfo = null)
                return@post
            }

            FirebaseMessaging.getInstance().send(body.toMessage())
            call.respond(HttpStatusCode.OK,typeInfo = null)
        }
    }
}
