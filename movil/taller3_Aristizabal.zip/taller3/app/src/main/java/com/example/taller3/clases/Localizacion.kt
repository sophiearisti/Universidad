package com.example.taller3.clases

class Localizacion {
}