package com.example.taller3.clases

import android.graphics.Bitmap

class UsuarioCelda (
    var nombre: String,
    var apellido: String,
    var uid: String?,
    var imagenDir:Bitmap
) {


}